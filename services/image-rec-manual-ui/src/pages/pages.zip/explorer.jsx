import React from 'react';
import { Container, Header, List, Image, Grid, Card, Icon, Collapse } from 'semantic-ui-react';
import './css/explorer.css';
const Explorer = () => (
  <Container id='page' fluid>
    <Header as='h1'>Explorer</Header>
    {/* <Container id="file-tree">
    </Container>
    <Container id="image-box">
      <Image src='/images/wireframe/white-image.png' size='medium' bordered />
    </Container> */}
    <Grid columns={2} id="mainBody">
      <Grid.Row id="mainRow">
        <Grid.Column color="green" width="3">
          <List id="fileList">
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
            <List.Item>Apples</List.Item>
            <List.Item>Pears</List.Item>
            <List.Item>Oranges</List.Item>
            <List.Item>example</List.Item>
          </List>
        </Grid.Column>
        <Grid.Column color="blue" width="12">
          {/* <Card id='imgcard'>
            
            <Card.Content>
              <Card.Header>Matthew</Card.Header>
              <Card.Meta>
                <span className='date'>Joined in 2015</span>
              </Card.Meta>
              <Card.Description>
                Matthew is a musician living in Nashville.
              </Card.Description>
            </Card.Content>
          </Card> */}

          <Image src='https://images.unsplash.com/photo-1489438497675-d1a8d6e0632e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=973&q=80' 
          wrapped ui={false} size="small"/>

        </Grid.Column>
      </Grid.Row>
    </Grid>
​
  </Container>
);
export default Explorer;
Collapse